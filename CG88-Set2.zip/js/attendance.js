
const names=["ช้างน้อย","หนิง","มีนา","ญาดา","ต้นหอม","ข้าวหอม","แหวน","โมจิ","นิวตรอน","แพง","แป้งหวาน"];
const today=new Date().toISOString().slice(0,10);
const db=JSON.parse(localStorage.getItem("cg_att")||"{}");
if(!db[today])db[today]={};
const list=document.getElementById("list"),sum=document.getElementById("summary"),his=document.getElementById("history");
his.value=today;
function render(day){
 let d=db[day]||{},c=0,s="";
 names.forEach(n=>{
 let t=d[n]?.time||"";
 if(t)c++;
 s+=`<label><input type="checkbox" ${t&&day==today?"checked":""} ${day!=today?"disabled":""} onchange="toggle('${n}',this.checked)"> ${n} <small>${t}</small></label><br>`;
 });
 sum.innerHTML=`<h3 style="color:${c==names.length?'green':'red'}">${c==names.length?"ครบแล้ว!!":"ขาด "+(names.length-c)+" คน"} (${c}/${names.length})</h3>`;
 list.innerHTML=s;
}
function toggle(n,v){
 if(v)db[today][n]={time:new Date().toLocaleTimeString("th-TH")};
 else delete db[today][n];
 localStorage.setItem("cg_att",JSON.stringify(db));
 render(today);
}
his.onchange=()=>render(his.value);
render(today);
